/*************
 * Name: Kendall Owens
 * Date: 10/15/2025
 * Assignment: 330L Lab Project
 * 
 *This class represents an Employee in a company.
 * It stores personal and employment-related details
 * such as name, ID, department, start date, employment
 * status, and hours worked. It also auto-registers
 * the employee to their department upon creation.
 * 
*/
public abstract class Employee implements Payable {
    //class properties
    private String StartDate;
    private boolean CurrentlyEmployed;
    private String Name;
    private Department Department;
    private double HoursWorked;
    private String EmpId;

    //Default contructor to initialize an employee object
    public Employee(String name ,String empid, String startdate, boolean currentlyemployed, Department department, double hoursworked ){
        Name = name;
        EmpId = empid;
        StartDate = startdate;
        CurrentlyEmployed = currentlyemployed;
        Department = department;
        HoursWorked = hoursworked;
        department.addEmployee(this);
    }

    //Getters and setters
    public String getStartDate() {
        return StartDate;
    }
    protected void setStartDate(String startdate) {
        StartDate = startdate;
    }
    public String getEmpId() {
        return EmpId;
    }
    protected void setEmpId(String empid) {
        EmpId = empid;
    }
    public boolean StillWorking() {
        return CurrentlyEmployed;
    }
    protected void setStillWorking(boolean currentlyemployed) {
        CurrentlyEmployed = currentlyemployed;
    }
    public String getName() {
        return Name;
    }
    protected void setName (String name) {
        Name = name;
    }
    public Department getDepartment() {
        return Department;
    }
    public double getHoursWorked() {
        return HoursWorked;
    }
    protected void setHoursWorked(double hoursworked){
        HoursWorked = hoursworked;
    }
    
    //Returns a formatted string with all employee details
    public String getEmpInfo() {
        return String.format("%s%n%s%s%n%s%s%n%s%s%n%s%b%n%s%.2f%n",
            "Employee Info",
            "Name: ", Name,
            "Start Date: ", StartDate,
            "Department: ", this.Department.getDepartmentName(),
            "Currently Employed? ", CurrentlyEmployed,
            "Hours Worked This Week: ", HoursWorked);
    } 

    
    //Overrides the default toString() to return employee
    @Override
    public String toString() {
        return getEmpInfo();
    }

    @Override
    public abstract double calculatePay();

}
