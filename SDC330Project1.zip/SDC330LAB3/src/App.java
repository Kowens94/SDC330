/**************
 * 
 * 
 * Name: Kendall Owens
 * Date: 10/16/25
 * Assignnment: SDC330L Project
 * Description:
 * This application demonstrates basic object-oriented
 * programming concepts including inheritance, composition,
 * polymorphism, and interface. It simulates an Employee Management System
 * with different employee types and departments.

 */
import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {

        //Welcome message and interface instruction
        System.out.println("Project Week 3 - Demo App - Kendall Owens");
        System.out.println();
        System.out.println("Welcome to the Employee Management System.");
        System.out.println();
        System.out.println("This interface allows you to view, add or make changes.");
        System.out.println();



        //Class with composition
        Department d = new Department("Information Technology", "501");
        Department d1 = new Department("Human Resources", "701");
        Department d2 = new Department("Maintenance", "801");
       
       
        //Sub Classes
        //Note that all of these classes extend the abstract class employee
        //The majority of this class contains concrete methods with the excpetion of
        // the method "calculate pay"
        Salaried s1 = new Salaried("Josh Allen", "E123", "09/07/2010", true, d, 40, 65000);
        Temp t1 = new Temp("Maggie Myers", "E345", "05/21/2025", false, d1, 31, "Higher Contracting Services", 42, 
        "09/31/2026");
        Hourly h1 = new Hourly("Sarah Roosevelt", "E456", "08/24/2020", true, d, 32, 32.45);
        Salaried s2 = new Salaried("Yoseph Zahid", "E567", "08/21/2018", true, d1, 40, 70000);

        //Create an ArrayList to store all employees
        ArrayList<Employee> employees = new ArrayList<>();

        //Add all employee objects to the list
        employees.add(s2);
        employees.add(s1);
        employees.add(t1);
        employees.add(h1);
       
     

        //Use of polymorphism in application
        ArrayList<Payable> payroll = new ArrayList<>();
        payroll.add(new Salaried("Umar Johnson", "E678", "07/23/2003", true, d, 40, 85000));
        payroll.add(new Hourly("Brittney Stockton", "E890", "05/08/2025", true, d1, 35, 45.23));

        employees.add((Employee) payroll.get(0));
        employees.add((Employee) payroll.get(1));

        //Display employee and department information
        System.out.println(s2.toString());
        System.out.println(s1.toString());
        System.out.println(t1.toString());
        System.out.println(h1.toString());
        System.out.println(d.getDepartmentInfo());
        System.out.println(d1.getDepartmentInfo());
        System.out.println(d2.getDepartmentInfo());

       System.out.println("\n--- Payroll Details ---");
       for (Payable p : payroll) {
            if (p instanceof Employee) {
                Employee e = (Employee) p;
                System.out.println(e.toString());       // Full employee info
            }
            System.out.println(p.getPayInfo());         // Pay info from interface
            System.out.println("------------------------");
}



        //Start interactive menu loop
        boolean running = true;
        while (running) {
            Scanner input = new Scanner(System.in);

            //Display menu options
            System.out.println("\nChoose an option:");
            System.out.println("1 - Edit employee");
            System.out.println("2 - View all employees");
            System.out.println("3 - Add new employee");
            System.out.println("0 - Exit");

            // Read user choice
            int choice = input.nextInt();
            input.nextLine(); // Consume newline

            //Handle user selection
            switch (choice) {
                case 1:
                //Placeholder for future edit funcitonality
                    System.out.println("Edit feature coming soon!");
                    break;

                // Display all employees in the list
                case 2:
                    System.out.println("\n--- Employee List ---");
                    for (Employee e : employees) {
                        System.out.println(e.toString());
                        System.out.println("----------------------");
                    }
                    break;

                //Placeholder for future add funcitonality
                case 3:
                    System.out.println("Add feature coming soon!:");
                    break;
                //Exit loop
                case 0:
                    running = false;
                    System.out.println("Exiting system. Goodbye!");
                    break;
                // Handle invalid input
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
