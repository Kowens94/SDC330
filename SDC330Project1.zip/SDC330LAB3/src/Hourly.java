/*************************************************
 * Name: Kendall Owens
 * Date: 10/15/2025
 * Assignment: 330L Lab
 * Description:
 * This class represents an hourly employee.
 * It extends the Employee class and adds a wage field
 * to track the employee's hourly pay rate.
*/


public class Hourly extends Employee {
    //class properties
    private double HourlyWage;

    //default contructor
    public Hourly (String name ,String empid, String startdate, boolean currentlyemployed, Department department, double hoursworked, double hourlywage) {
        super(name, empid, startdate, currentlyemployed, department, hoursworked);
        HourlyWage = hourlywage;
    }

    //getter and setters
    public double getHourlyWage(){
        return HourlyWage;
    }
    protected void setHourlyWage(double hourlywage) {
        HourlyWage = hourlywage;
    }

    
    //Returns formatted string with wage information
    public String getWageInfo(){
        return String.format("%s%.2f%n",
        "Hourly Wage: $",HourlyWage);
    }

    //Overrides toString method
    @Override
    public String toString() {
        return String.format("%s%s",
        super.toString(), getWageInfo());
    }
    
    @Override
    public double calculatePay() {
        return HourlyWage * super.getHoursWorked();
    }

    @Override
    public String getPayInfo() {
        return String.format("%sHourly Rate: $%.2f\nWeekly Pay: $%.2f",super.toString(), HourlyWage, calculatePay());
    }


}
