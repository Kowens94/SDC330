public interface Payable {
    double calculatePay();
    String getPayInfo();   
}
