/*************************************************
 * Name: Kendall Owens
 * Date: 10/11/12025
 * Assignment: SDC330L Project
 * Description:
 * This class represents a salaried employee.
 * It extends the Employee class and adds salary-specific
 * fields such as base annual salary and calculated bi-weekly pay.
 *************************************************/

public class Salaried extends Employee {
    //Class properties
    private int BaseSalary;
    private double BiWeeklyCheck;
    
    //default constructor
    public Salaried(String name ,String empid, String startdate, boolean currentlyemployed, Department department, double hoursworked, 
    int basesalary) {
        super(name, empid, startdate, currentlyemployed, department, hoursworked);
        BaseSalary = basesalary;
        setBiWeeklySalary(BaseSalary);
    }

    //getters and setters
    public int getBaseSalary() {
        return BaseSalary;
    }
    public void setBaseSalary(int basesalary) {
        BaseSalary = basesalary;
    }
    public double getBiWeeklyCheck() {
        return BiWeeklyCheck;
    }
    public void setBiWeeklySalary(double BaseSalary) {
        BiWeeklyCheck = BaseSalary/26;
    }


    //Returns a formatted string with salary details
    public String getSalaryInfo() {
        return String.format("%s%s%n%s%d%n%s%.2f%n",
        super.getName(), "'s Salary Information",
        "Base Salary: $", BaseSalary,
        "BiWeekly Earnings: $" , BiWeeklyCheck);
    }

    //Overrides the default toString() method
    @Override
    public String toString(){
        return getSalariedEmployeeInfo();
    }

    //Returns full employee info
    public String getSalariedEmployeeInfo(){
        return String.format("%s%s",
        super.toString(),
        getSalaryInfo());
    }

    @Override
    public double calculatePay() {
        return BaseSalary / 52;
    }

    @Override
    public String getPayInfo() {
        return String.format("Hours Worked: %.2f\nWeekly Pay: $%.2f", super.getHoursWorked(), calculatePay());
    }

    }

