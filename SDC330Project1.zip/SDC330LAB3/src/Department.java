/*************************************************
 * Name: Kendall Owens
 * Date: 10/15/2025
 * Description:
 * This class represents a Department within an organization.
 * It stores the department's name, code, and a list of employees
 * assigned to it. Employees can be added to the department,
 * and department details can be retrieved in a formatted string.
 */


import java.util.ArrayList;

public class Department {
    //Department properties
    private String DepartmentName;
    private String Code;
    // A list of employess assigned to this department
    private ArrayList<Employee> Staff;

   
    //Constructor to initialize a Department object.
    public Department (String departmentname, String code) {
        DepartmentName = departmentname;
        Code = code;
        Staff = new ArrayList<Employee>();
    }
    
    //getters and setters
    public String getDepartmentName() {
        return DepartmentName;
    }
    protected void setDepartmentName(String departmentname) {
        DepartmentName = departmentname;
    }
    public String getDepartmentCode() {
        return Code;
    }
    protected void setDepartmentCode(String code) {
        Code = code;
    }

    public ArrayList<Employee> getStaff() {
        return Staff;
    }

    // Adds an employee to the department's staff list
    public void addEmployee(Employee val) {
        Staff.add(val);
    }

    //Returns a formatted string with department details
    public String getDepartmentInfo() {
        return String.format("%s%n%s%s%n%s%s%n%s%s%n",
        "Department Info ",
                "Department Name: ", DepartmentName,
                "Department Code: ", Code,
                "Staff Size: ", Staff.size());
    }

    //Overrides to string method
    @Override
    public String toString() {
        return String.format("%s%s", 
        super.toString(), getDepartmentInfo());
    }
    
}
