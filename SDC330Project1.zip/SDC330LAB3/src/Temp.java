/*************************************************
 * Name: Kendall Owens
 * Date: 10/15/2025
 * Assignment: SDC330L Project
 * Description:
 * This class represents a temporary employee.
 * It extends the Employee class and adds contract-specific
 * details such as contractor name, contract rate, and end date.
 *************************************************/


public class Temp extends Employee {
    //class properties
    private String ContractorName;
    private double ContractRate;
    private String ContractEndDate;

    //default constructor
    public Temp(String name ,String empid, String startdate, boolean currentlyemployed, Department department, double hoursworked,
    String contractorname, double contractrate, String contractenddate) {
    super(name, empid, startdate, currentlyemployed, department, hoursworked);
    ContractorName = contractorname;
    ContractRate = contractrate;
    ContractEndDate = contractenddate;
    }

    //getters and setters
    public String getContractName() {
        return ContractorName;
    }
    public void setContractor(String contractorname) {
        ContractorName = contractorname;
    }
    public double getContractRate() {
        return ContractRate;
    }
    public void setContractRate(double contractrate) {
        ContractRate = contractrate;
    }
    public String getContractEndDate() {
        return ContractEndDate;
    }
    public void setContractEndDate(String contractenddate) {
        ContractEndDate = contractenddate;
    }

    //Returns a formatted string with contract details
    public String getContractInfo() {
        return String.format("%s%n%s%s%n%s%s%n%s%s%n",
        "Contract Information",
                "Contractor Name: ", ContractorName,
                "Contractor Rate: ", ContractRate,
                "Contract End Date: ", ContractEndDate);
    }

    //Overrides the default toString() method
    @Override 
    public String toString() {
        return String.format("%s%s",super.toString(), getContractInfo());
    }

    @Override
    public double calculatePay() {
        return ContractRate * super.getHoursWorked();
    }

    @Override
    public String getPayInfo() {
        return String.format("Hourly Rate: $%.2f\nWeekly Pay: $%.2f", ContractRate, calculatePay());
    }

    }


     

